#include "../headers/Shape2D.h"

double Shape2D::area() const
{
    return mArea;
}

double Shape2D::perimeter() const
{
    return mPerimeter;
}