#pragma once

class Shape1D
{
};