#include "Shape3D.h"

double Shape3D::volume()
{
    return mVolume;
}

double Shape3D::surfaceArea()
{
    return mSurfaceArea;
}